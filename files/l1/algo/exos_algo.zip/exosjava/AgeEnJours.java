import java.util.Scanner;

public class AgeEnJours {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez votre age en annees : ");
        int ageEnAnnees = scanner.nextInt();
        int ageEnJours = ageEnAnnees * 365;
        System.out.println("Votre age en jours est d'environ : " + ageEnJours + " jours.");
        scanner.close();
    }
} 