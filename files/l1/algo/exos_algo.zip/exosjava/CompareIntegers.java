import java.util.Scanner;

public class CompareIntegers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez le premier entier : ");
        int premier = scanner.nextInt();
        System.out.println("Entrez le deuxieme entier : ");
        int deuxieme = scanner.nextInt();

        if (premier == deuxieme) {
            System.out.println("Les entiers sont egaux.");
        } else if (premier < deuxieme) {
            System.out.println("Le premier entier est inferieur.");
        } else {
            System.out.println("Le premier entier est superieur.");
        }

        scanner.close();
    }
} 