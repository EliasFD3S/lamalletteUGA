import java.util.Scanner;

public class CompteCode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez une chaine : ");
        String chaine = scanner.nextLine();

        int compteur = 0;
        for (int i = 0; i <= chaine.length() - 4; i++) {
            if (chaine.charAt(i) == 'c' && chaine.charAt(i + 1) == 'o' &&
                chaine.charAt(i + 3) == 'e') {
                compteur++;
            }
        }

        System.out.println("Le nombre de 'coXe' est : " + compteur);
        scanner.close();
    }
} 