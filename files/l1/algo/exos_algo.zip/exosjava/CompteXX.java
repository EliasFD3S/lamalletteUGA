import java.util.Scanner;

public class CompteXX {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez une chaine : ");
        String chaine = scanner.nextLine();

        int compteur = 0;
        for (int i = 0; i < chaine.length() - 1; i++) {
            if (chaine.substring(i, i + 2).equals("xx")) {
                compteur++;
            }
        }

        System.out.println("Le nombre de 'xx' est : " + compteur);
        scanner.close();
    }
} 