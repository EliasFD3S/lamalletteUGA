import java.util.Scanner;

public class ContientNombre {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] tableau = {3, 7, 15, 20, 42, 8, 13, 27};

        System.out.println("Entrez un nombre a rechercher : ");
        int nombreRecherche = scanner.nextInt();

        boolean trouve = false;
        for (int nombre : tableau) {
            if (nombre == nombreRecherche) {
                trouve = true;
            }
        }

        if (trouve) {
            System.out.println("Le nombre est present dans le tableau.");
        } else {
            System.out.println("Le nombre n'est pas present dans le tableau.");
        }

        scanner.close();
    }
} 