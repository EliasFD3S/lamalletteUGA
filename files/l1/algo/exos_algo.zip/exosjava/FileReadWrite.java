import java.io.*;
import java.util.Scanner;

public class FileReadWrite {
    public static void main(String[] args) throws IOException {
        String fileName = "phrases.txt";
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Veuillez entrer 3 phrases :");
        for (int i = 1; i <= 3; i++) {
            System.out.print("Entrez la phrase " + i + " : ");
            String phrase = scanner.nextLine();
            writer.write(phrase);
            writer.newLine();
        }
        writer.close();

        System.out.println("\nContenu du fichier :");
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        reader.close();
        scanner.close();
    }
} 