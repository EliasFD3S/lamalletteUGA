import java.util.Arrays;

public class JazzifyChords {
    public static String[] jazzify(String[] chords) {
        if (chords.length == 0) {
            return new String[0];
        }

        String[] jazzifiedChords = new String[chords.length];
        for (int i = 0; i < chords.length; i++) {
            if (chords[i].endsWith("7")) {
                jazzifiedChords[i] = chords[i];
            } else {
                jazzifiedChords[i] = chords[i] + "7";
            }
        }
        return jazzifiedChords;
    }

    public static void main(String[] args) {
        String[] accords = {"G", "F", "C", "F7"};
        System.out.println("Accords jazzifiés : " + Arrays.toString(jazzify(accords)));
    }
} 