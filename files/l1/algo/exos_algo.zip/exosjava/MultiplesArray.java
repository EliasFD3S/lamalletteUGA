import java.util.Arrays;

public class MultiplesArray {
    public static int[] generateMultiples(int num, int length) {
        int[] multiples = new int[length];
        for (int i = 0; i < length; i++) {
            multiples[i] = num * (i + 1);
        }
        return multiples;
    }

    public static void main(String[] args) {
        int[] result = generateMultiples(5, 10);
        System.out.println("Multiples de 5 : " + Arrays.toString(result));
    }
} 