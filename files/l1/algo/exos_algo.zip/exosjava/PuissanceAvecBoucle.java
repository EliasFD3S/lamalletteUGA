import java.util.Scanner;

public class PuissanceAvecBoucle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez un nombre de base : ");
        int base = scanner.nextInt();
        System.out.println("Entrez un nombre d'exposant : ");
        int exposant = scanner.nextInt();

        int resultat = 1;
        for (int i = 0; i < exposant; i++) {
            resultat *= base;
        }

        System.out.println("Le resultat est : " + resultat);
        scanner.close();
    }
} 