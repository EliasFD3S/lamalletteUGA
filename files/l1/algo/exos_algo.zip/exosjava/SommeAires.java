public class SommeAires {
    public static void main(String[] args) {
        double b1 = 5.0, h1 = 7.0;
        double b2 = 8.5, h2 = 6.0;
        double b3 = 10.0, h3 = 4.5;

        double aire1 = (b1 * h1) / 2;
        double aire2 = (b2 * h2) / 2;
        double aire3 = (b3 * h3) / 2;
        double sommeAires = aire1 + aire2 + aire3;

        System.out.println("Aire du triangle 1 : " + aire1 + " cm²");
        System.out.println("Aire du triangle 2 : " + aire2 + " cm²");
        System.out.println("Aire du triangle 3 : " + aire3 + " cm²");
        System.out.println("Somme des aires : " + sommeAires + " cm²");
    }
} 