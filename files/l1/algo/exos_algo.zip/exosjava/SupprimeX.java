import java.util.Scanner;

public class SupprimeX {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez une chaine : ");
        String chaine = scanner.nextLine();

        if (chaine.length() <= 1) {
            System.out.println("Resultat : " + chaine);
            return;
        }

        char premier = chaine.charAt(0);
        char dernier = chaine.charAt(chaine.length() - 1);
        String milieu = chaine.substring(1, chaine.length() - 1).replace("x", "");
        String resultat = premier + milieu + dernier;

        System.out.println("Resultat : " + resultat);
        scanner.close();
    }
} 