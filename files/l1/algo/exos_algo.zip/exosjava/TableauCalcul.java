import java.util.Scanner;

public class TableauCalcul {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez la taille du tableau : ");
        int taille = scanner.nextInt();

        int[] tableau = new int[taille];
        System.out.println("Entrez les éléments du tableau : ");
        for (int i = 0; i < taille; i++) {
            tableau[i] = scanner.nextInt();
        }

        int min = tableau[0];
        int max = tableau[0];
        for (int i = 1; i < tableau.length; i++) {
            if (tableau[i] < min) min = tableau[i];
            if (tableau[i] > max) max = tableau[i];
        }

        int somme = min + max;
        int[] tableauRange = new int[somme];
        for (int i = 0; i < somme; i++) {
            tableauRange[i] = i + 1;
        }

        System.out.println("Le tableau généré allant de 1 à " + somme + " est : ");
        for (int i : tableauRange) {
            System.out.print(i + " ");
        }

        scanner.close();
    }
} 