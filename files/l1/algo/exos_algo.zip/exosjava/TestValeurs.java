import java.util.Scanner;

public class TestValeurs {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez deux entiers : ");
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        boolean resultat = (a == 10 || b == 10) || (a + b == 10);
        System.out.println("Resultat : " + resultat);
        scanner.close();
    }
} 