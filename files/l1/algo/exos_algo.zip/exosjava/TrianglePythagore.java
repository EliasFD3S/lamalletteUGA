public class TrianglePythagore {
    public static void main(String[] args) {
        double KP = 7.2;
        double HP = 15.4;
        double HK = Math.sqrt(Math.pow(KP, 2) + Math.pow(HP, 2));
        System.out.printf("La longueur de l'hypotenuse HK est : %.2f", HK);
    }
} 